const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Allow frontend to communicate with backend
app.use(cors());
app.use(express.json());

// Test route (optional)
app.get("/", (req, res) => {
  res.json({ message: "Backend is running!" });
});

// API route to receive transactions from frontend
app.post("/api/transactions", (req, res) => {
  const transaction = req.body;

  // Log received transaction
  console.log("📌 New transaction received:");
  console.log(transaction);

  // TODO: Save to database if needed
  // e.g., MongoDB, PostgreSQL, MySQL, Firebase, etc.

  res.status(201).json({
    success: true,
    message: "Transaction received and saved successfully.",
    transaction,
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Backend running at http://localhost:${PORT}`);
});
