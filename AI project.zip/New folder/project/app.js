// --- 1. KEYWORD RULESET ---
// Defines the rules for keyword-based tagging (Taxonomy)
const TAG_RULES = {
  Groceries: ["walmart", "kroger", "whole foods", "costco", "market", "produce","reliance"],
  Utilities: ["electric", "water", "gas bill", "utility", "internet", "verizon", "att"],
  Transport: ["shell", "chevron", "exxon", "gas station", "uber", "lyft", "parking"],
  Subscription: ["netflix", "spotify", "amazon prime", "hulu", "adobe","hotstar"],
  Restaurants: ["cafe", "coffee", "starbucks", "dinner", "restaurant", "mcdonalds","kfc"],
  "Rent/Mortgage": ["rent", "mortgage", "housing", "lease"],
  Health: ["pharmacy", "hospital", "doctor", "cvs", "insurance"],
};

// --- 2. CORE LOGIC FUNCTION ---
function assignTags(description, amount) {
  const lowerDesc = description.toLowerCase().trim();
  const tags = [];

  // --- 2a. Keyword Matching ---
  for (const category in TAG_RULES) {
    const keywords = TAG_RULES[category];
    if (keywords.some((keyword) => lowerDesc.includes(keyword))) {
      tags.push(category);
    }
  }

  // Default tag if no keyword match found
  if (tags.length === 0) {
    tags.push("Miscellaneous");
  }

  // --- 2b. Simple AI Logic (Thresholds) ---
  // Logic 1: High Value Alert (Amount Threshold)
  if (amount >= 500) {
    tags.push("Large Expense");
  }
  // Logic 2: Budget Monitoring (Threshold + Keyword Check)
  if (
    amount >= 50 &&
    tags.some((tag) => ["Groceries", "Restaurants", "Transport"].includes(tag))
  ) {
    tags.push("Budget Alert");
  }

  return tags;
}

// --- 3. UI AND RENDERING ---

function getTagClass(tag) {
  switch (tag) {
    case "Groceries":
      return "tag-success";
    case "Subscription":
      return "tag-info";
    case "Utilities":
      return "tag-info";
    case "Transport":
      return "tag-warning";
    case "Large Expense":
      return "tag-danger";
    case "Budget Alert":
      return "tag-danger";
    default:
      return "tag-default";
  }
}

function createTagElement(tag) {
  const span = document.createElement("span");
  // Fix: add base 'tag' class + style class
  span.className = "tag " + getTagClass(tag);
  span.textContent = tag;
  return span;
}

function displayError(message) {
  const errorElement = document.getElementById("error-message");
  if (!errorElement) return;
  errorElement.textContent = message;
  errorElement.classList.remove("hidden");
  setTimeout(() => errorElement.classList.add("hidden"), 3000); // Hide after 3 seconds
}

// OPTIONAL: send the transaction to a backend API
function sendToBackend(transaction) {
  // Change this URL to match your backend route
  const url = "http://localhost:5000/api/transactions";

  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(transaction),
  }).catch((err) => {
    console.error("Error sending transaction to backend:", err);
  });
}

function processTransaction() {
  const descriptionInput = document.getElementById("description");
  const amountInput = document.getElementById("amount");

  if (!descriptionInput || !amountInput) {
    console.error("Missing #description or #amount elements in HTML.");
    return;
  }

  const description = descriptionInput.value.trim();
  const amount = parseFloat(amountInput.value);

  if (!description || isNaN(amount) || amount <= 0) {
    displayError("Please enter a valid description and a positive amount.");
    return;
  }

  // 1. Assign Tags using Core Logic
  const assignedTags = assignTags(description, amount);

  // 2. Build List Item (HTML)
  const listItem = document.createElement("li");
  listItem.className =
    "p-3 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col space-y-1";

  // Description and Amount Line
  const detailsDiv = document.createElement("div");
  detailsDiv.className = "flex justify-between items-center";
  detailsDiv.innerHTML = `
    <span class="text-sm font-medium text-gray-800">${description}</span>
    <span class="text-lg font-bold text-red-600">$${amount.toFixed(2)}</span>
  `;

  // Tags Line
  const tagsDiv = document.createElement("div");
  assignedTags.forEach((tag) => {
    tagsDiv.appendChild(createTagElement(tag));
  });

  listItem.appendChild(detailsDiv);
  listItem.appendChild(tagsDiv);

  // 3. Add to Log
  const listContainer = document.getElementById("transaction-list");
  const placeholder = document.getElementById("log-placeholder");

  if (!listContainer) {
    console.error("Missing #transaction-list element in HTML.");
    return;
  }

  if (placeholder) placeholder.remove();

  // Prepend new item to the top
  listContainer.prepend(listItem);

  // 4. Update Count
  const count = listContainer.children.length;
  const countElement = document.getElementById("transaction-count");
  if (countElement) {
    countElement.textContent = `${count} Items`;
  }

  // 5. Clear Inputs
  descriptionInput.value = "";
  amountInput.value = "";
  descriptionInput.focus();

  // 6. Send to backend (optional)
  sendToBackend({
    description,
    amount,
    tags: assignedTags,
    createdAt: new Date().toISOString(),
  });
}

// --- 4. Initialize Mock Data (Optional, for demo) ---
function processTransactionMock(desc, amt) {
  const descriptionInput = document.getElementById("description");
  const amountInput = document.getElementById("amount");
  if (!descriptionInput || !amountInput) return;

  descriptionInput.value = desc;
  amountInput.value = amt;
  processTransaction();
}

document.addEventListener("DOMContentLoaded", () => {
  // Optional: Run a few mock transactions on load
  processTransactionMock("Netflix monthly fee", 19.99);
  processTransactionMock("Utility bill - Electric Co.", 125.5);
  processTransactionMock("Walmart Superstore run", 85.0);
  processTransactionMock("Flight ticket to London", 750.0);

  // Attach button handler if it exists
  const button = document.querySelector('[onclick="processTransaction()"]');
  if (button) {
    button.onclick = processTransaction;
  }
});
